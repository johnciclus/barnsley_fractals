#!/bin/bash 
java -jar Barnsley\ Fractals.jar

